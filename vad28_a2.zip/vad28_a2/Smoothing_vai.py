import numpy as np
np.seterr(divide='ignore', invalid='ignore')
def smoothing(evidence_data_add, total_day):
    f = open(evidence_data_add, "r")
    smoothed_x=[]
    smooth_x_ = np.zeros(shape=(2,100))
    smooth_y_ =np.zeros(shape=(2,2))
    priorf = np.array([[0.5], [0.5]])
    priorb = np.array([[1.0], [1.0]])
    print(priorf)

    smooth_x_ = fow(evidence_data_add, priorf)
    # Foward val-> a,b
    smooth_y_ = back(evidence_data_add, priorb) # Backward val-> c,d
    print("Values for smoothx")
    print(smooth_x_)
    print("-------|||||||||||||||||")
    print(smooth_y_)
    for i in range(100):
        x = i;
        y = 100-i-1
        #print(np.shape(smooth_x_[x]))
        #print(np.shape(smooth_y_[y]))
        smooth_x_[x] = np.array(smooth_x_[x])
        smooth_y_[y] = np.array(smooth_y_[y])
        num = np.matmul(smooth_x_[x],smooth_y_[y])
        print(num)
        print("----")
        sum = (smooth_y_[y][0]*smooth_x_[x][0])+(smooth_y_[y][1]*smooth_x_[x][1])
        print(sum)
        smoothed_x.append(np.divide(num, sum))

    return smoothed_x

def fow(evidence_data_add, priorf):
    smoothed1 = np.zeros(shape=(2,1))
    fwd = []

    # 2
    prior = priorf
    f = open(evidence_data_add, "r")
    for line in f:
        sensor = 'take' in line
        rain = np.array([[0.7, 0.3], [0.3, 0.7]])
        if sensor:
            p_val = np.array([[0.9, 0.0], [0.0, 0.2]])
            a = np.matmul(p_val, rain)
            temp = np.matmul(a, prior)
            tempsum = temp[0] + temp[1]
            temp[0] = temp[0] / tempsum
            temp[1] = temp[1] / tempsum
            prior = temp

        else:
            n_val = np.array([[0.1,0.0],[0.0,0.8]])
            a = np.matmul(n_val, rain)
            temp = np.matmul(a, prior)
            tempsum = temp[0] + temp[1]
            temp[0] = temp[0] / tempsum
            temp[1] = temp[1] / tempsum
            prior = temp
        fwd.append(prior)
        smoothed1 = np.vstack([smoothed1, temp])

    #print("Smootheed1 for fow : ", smoothed1);
    print("Smootheed1 for fow : ", fwd);
    return fwd

def back(evidence_data_add, prior):
    f = reversed(list(open(evidence_data_add, "r")))

    smoothed1 = []
    for line in f:
        sensor = 'take' in line
        rain = np.array([[0.7, 0.3], [0.3, 0.7]])
        if sensor:
            p_val = np.array([[0.9, 0.0], [0.0, 0.2]])
            a = np.matmul(rain, p_val)
            # print(rain)
            temp = np.matmul(a, prior)
            tempsum = temp[0] + temp[1]
            temp[0] = temp[0] / tempsum
            temp[1] = temp[1] / tempsum
            prior = temp
        else:
            n_val = np.array([[0.1,0.0],[0.0,0.8]])
            a = np.matmul(rain, n_val)
            temp = np.matmul(a, prior)
            tempsum = temp[0] + temp[1]
            temp[0] = temp[0] / tempsum
            temp[1] = temp[1] / tempsum
            prior = temp
        smoothed1.append(prior)

    print("Smootheed1 for back : ", smoothed1)
    return smoothed1




# following lines are main function:
evidence_data_add = "assign2_umbrella.txt"
total_day = 100
    # the prior distribution on the initial state, P(X0). 50% rainy, and 50% sunny on day 0.

smoothed_x = smoothing(evidence_data_add, total_day)
print(smoothed_x)
for i in range(100):
    print("Day " + str(i+1) + ": rain " + str(smoothed_x[i]) + ", sunny " + str(1 - smoothed_x[i]))