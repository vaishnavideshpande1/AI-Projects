import numpy as np
import pandas as pd


def get_p_b_cd():
    # you need to implement this method.
    p_b_cd = np.zeros((3,3,2),dtype = np.float)
    for b in range(1,p_b_cd.shape[0]+1):
        for c in range(1,p_b_cd.shape[1]+1):
            for d in range(1,p_b_cd.shape[2]+1):
                count_total = np.sum((data["c"]==c) & (data["d"]==d))
                count_b = np.sum((data["b"]==b) & (data["c"]==c) & (data["d"]==d))
                p_b_cd[b-1,c-1,d-1] = count_b / count_total
    # print(p_b_cd)
    return p_b_cd


def get_p_a_be():
    # you need to implement this method.
    p_a_be = np.zeros((2,3,2),dtype = np.float)
    for a in range(1,p_a_be.shape[0]+1):
        for b in range(1,p_a_be.shape[1]+1):
            for e in range(1,p_a_be.shape[2]+1):
                #print("a:"+str(a),"b:"+str(b),"e:"+str(e))
                count_total = np.sum((data["b"] == b) & (data["e"] == e))
                count_a = np.sum((data["a"] == a) & (data["b"] == b) & (data["e"] == e))
                #print(count_a, count_total, count_a/count_total)
                p_a_be[a - 1, b - 1, e - 1] = float(count_a) / float(count_total)
    #print(p_a_be)
    return p_a_be


# following lines are main function:
data_add = open("C:\\Users\\rvais\\Desktop\\hw2\\assign2_BNdata.txt")
data = pd.read_csv(data_add, delimiter=r'\s+')
m = data.shape[0]
if __name__ == '__main__':


    # probability distribution of b.
    p_b_cd = get_p_b_cd()
    for c in range(3):
        for d in range(2):
            for b in range(3):
                print("P(b=" + str(b + 1) + "|c=" + str(c + 1) + ",d=" + str(d + 1) + ")=" + str(p_b_cd[b][c][d]))

    # probability distribution of a.
    p_a_be = get_p_a_be()
    for b in range(3):
        for e in range(2):
            for a in range(2):
                print("P(a=" + str(a + 1) + "|b=" + str(b  + 1) + ",e=" + str(e + 1) + ")=" + str(p_a_be[a][b][e]))
