import StringDouble
from heapq import heappush, heapreplace


class BeamSearch:

    graph = {}
    heap = []

    def __init__(self, input_graph):
        self.graph = input_graph
        return

    def beamSearch(self, pre_words, beamK, maxToken):
        heappush(self.heap, StringDouble.StringDouble(pre_words, 1))
        for i in range(len(pre_words.split()), maxToken):
            #print(self.heap)
            self.search(10, beamK)
        return self.heap[-1]

    @staticmethod
    def heap_add(heap_aux, length, sentence_score):
        if len(heap_aux) < length:
            heappush(heap_aux, sentence_score)
        elif sentence_score > heap_aux[0]:
            heapreplace(heap_aux, sentence_score)

    def search(self, length, beamK):
        heap_aux = []
        for sentence_score in self.heap:
            current = sentence_score.string.split()[-1]

            next_words = None
            if current in self.graph:
                next_words = self.graph[current]
            else:
                BeamSearch.heap_add(heap_aux, length, sentence_score)
                continue

            for word_score in next_words[:min(len(next_words), beamK)]:
                new_sentence = sentence_score.string + " " + word_score.string
                new_score = sentence_score.score * word_score.score
                new_sentence_score = StringDouble.StringDouble(new_sentence, new_score)
                BeamSearch.heap_add(heap_aux, length, new_sentence_score)

        self.heap = heap_aux