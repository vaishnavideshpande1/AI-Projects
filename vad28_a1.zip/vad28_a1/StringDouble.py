class StringDouble:

    string = ""
    score = 0.0

    def __init__(self, a, b):
        self.string = a
        self.score = b

    def __cmp__(self, other):
        return self.score < other.score

    def __lt__(self, other):
        return self.score < other.score

    def __str__(self):
        return self.string+"-"+self.score

    def __repr__(self):
        return self.string+"-"+str(self.score)

    def __eq__(self, other):
        if isinstance(other, StringDouble):
            return self.string == other.string
        return self.string == other
