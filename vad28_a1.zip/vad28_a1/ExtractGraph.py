import math
import StringDouble


class ExtractGraph:

    # key is head word; value stores next word and corresponding probability.
    graph = {}
    counts = {}

    sentences_add ="C:/Users/rvais/Desktop/vad28_a1/assign1_sentence.txt"

    def __init__(self):
        # Extract the directed weighted graph, and save to {head_word, {tail_word, probability}}
        self.process_file()
        self.compute_probabilities()
        return

    def increment_count(self, head_word, tail_word):
        if head_word in self.counts:
            word_counts = self.counts[head_word]
            if tail_word in word_counts:
                word_counts[tail_word] += 1
            else:
                word_counts[tail_word] = 1
        else:
            word_counts = {tail_word: 1}
            self.counts[head_word] = word_counts

    # Update counts
    def process_sentence(self, sentence):
        words = sentence.split(" ")
        current = words[0]
        for word in words[1:]:
            self.increment_count(current, word)
            current = word

    def process_file(self):
        with open(self.sentences_add) as f:
            for line in f:
                self.process_sentence(line)

    def compute_probabilities(self):
        for head_word in self.counts:
            tail_word_counts = self.counts[head_word]

            # compute probability using Boltzmann distribution / Softmax
            denom = 0
            d = []

            for tail_word in tail_word_counts:
                #prob = math.exp(tail_word_counts[tail_word])
                prob = tail_word_counts[tail_word]
                tail_prob = StringDouble.StringDouble(tail_word, prob)
                d.append(tail_prob)
                denom += prob

            for tail_prob in d:
                tail_prob.score /= denom
            d.sort(key=lambda x: x.score, reverse=True)
            self.graph[head_word] = d

    def getProb(self, head_word, tail_word):
        if head_word not in self.graph:
            return 0.0
        d = self.graph[head_word]
        for word in d:
            if word == tail_word:
                return word.score
        return 0.0